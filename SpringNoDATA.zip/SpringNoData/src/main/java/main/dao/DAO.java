package main.dao;

import java.util.List;

public interface DAO<T> {
	
	void insertar(T entidad);
	List<T> listar();
	void borrar(T entidad);
	
}
