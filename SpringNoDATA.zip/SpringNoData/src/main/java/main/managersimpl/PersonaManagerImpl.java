package main.managersimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.dao.DAO;
import main.dependencies.Persona;
import main.managers.Manager;



@Service
public class PersonaManagerImpl implements Manager<Persona>{
	
	@Autowired
	private DAO<Persona> pdao;

	@Override
	public void insertar(Persona persona) {
		pdao.insertar(persona);		
	}

	@Override
	public List<Persona> listar() {
		return pdao.listar();
	}

	@Override
	public void borrar(Persona persona) {
		pdao.borrar(persona);		
	}
	
}
