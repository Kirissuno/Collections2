package main.managersimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.dao.DAO;
import main.dependencies.Profesor;
import main.managers.Manager;

@Service
public class ProfesorManagerImpl implements Manager<Profesor> {

	@Autowired
	private DAO<Profesor> prdao;
	
	@Override
	public void insertar(Profesor pr) {
		prdao.insertar(pr);
	}

	@Override
	public List<Profesor> listar() {
		return prdao.listar();
	}

	@Override
	public void borrar(Profesor pr) {
		prdao.borrar(pr);
	}

}
