package main.managersimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.dao.DAO;
import main.dependencies.Alumno_Asignatura;
import main.managers.Manager;

@Service
public class Alumno_AsignaturaManagerImpl implements Manager<Alumno_Asignatura>{

	@Autowired
	private DAO<Alumno_Asignatura> aadao;
	
	@Override
	public void insertar(Alumno_Asignatura aa) {
		aadao.insertar(aa);
	}

	@Override
	public List<Alumno_Asignatura> listar() {
		return aadao.listar();
	}

	@Override
	public void borrar(Alumno_Asignatura aa) {
		aadao.borrar(aa);
	}

}
