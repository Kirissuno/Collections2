package main.managersimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.dao.DAO;
import main.dependencies.Titulacion;
import main.managers.Manager;

@Service
public class TitulacionManagerImpl implements Manager<Titulacion>{
	
	@Autowired
	private DAO<Titulacion> tdao;

	@Override
	public void insertar(Titulacion tit) {
		tdao.insertar(tit);		
	}

	@Override
	public List<Titulacion> listar() {
		return tdao.listar();
	}

	@Override
	public void borrar(Titulacion tit) {
		tdao.borrar(tit);
	}
	
}
