package main.managersimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.dao.DAO;
import main.dependencies.Asignatura;
import main.managers.Manager;

@Service
public class AsignaturaManagerImpl implements Manager<Asignatura> {

	@Autowired
	private DAO<Asignatura> asdao;
	
	@Override
	public void insertar(Asignatura as) {
		asdao.insertar(as);
	}

	@Override
	public List<Asignatura> listar() {
		return asdao.listar();
	}

	@Override
	public void borrar(Asignatura as) {
		asdao.borrar(as);
	}

}
