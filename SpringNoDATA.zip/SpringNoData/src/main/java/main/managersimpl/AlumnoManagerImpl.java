package main.managersimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.dao.DAO;
import main.dependencies.Alumno;
import main.managers.Manager;

@Service
public class AlumnoManagerImpl implements Manager<Alumno>{

	@Autowired
	private DAO<Alumno> adao;
	
	@Override
	public void insertar(Alumno al) {
		adao.insertar(al);
	}

	@Override
	public List<Alumno> listar() {
		return adao.listar();
	}

	@Override
	public void borrar(Alumno al) {
		adao.borrar(al);
	}

}
