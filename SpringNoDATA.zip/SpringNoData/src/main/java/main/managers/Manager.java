package main.managers;

import java.util.List;

public interface Manager<T> {
	
	void insertar(T entidad);
	List<T> listar();
	void borrar(T entidad);
	
}
