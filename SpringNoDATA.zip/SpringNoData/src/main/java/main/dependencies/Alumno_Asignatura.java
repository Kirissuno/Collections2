package main.dependencies;

import java.io.Serializable;

import javax.persistence.*;

@Entity(name="alumno_asignatura")
@Table(name="alumno_asignatura")
public class Alumno_Asignatura {
	
	@Embeddable
	public static class compuesta implements Serializable{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public compuesta(Alumno a, Asignatura b, int c) {
			this.idalumno = a;
			this.idasignatura = b;
			this.numeromatricula = c;
		}
		
		public compuesta() {}
		
		@ManyToOne
		@JoinColumn(name="idalumno", referencedColumnName="idalumno")
		private Alumno idalumno;
		
		@ManyToOne
		@JoinColumn(name="idasignatura", referencedColumnName="idasignatura")
		private Asignatura idasignatura;
		
		private int numeromatricula;
		
		@Override
		public String toString() {
			return idalumno.getIdalumno()+" "+idasignatura.getIdasignatura()+" "+numeromatricula;
		}
	}
	
	@EmbeddedId
	compuesta compuesta;

	public Alumno_Asignatura(compuesta primary) {
		super();
		this.compuesta = primary;
	}

	public Alumno_Asignatura() {
		super();
	}

	@Override
	public String toString() {
		return compuesta.toString();
	}
	
	

}
