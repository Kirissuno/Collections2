package main.dependencies;

import javax.persistence.*;

@Entity(name="profesor")
@Table(name="profesor")
public class Profesor extends Persona{
	
	private String idprofesor;	

	public Profesor() {
		super();
	}

	public Profesor(String idprofesor, String dni) {
		super.setDni(dni);
		this.idprofesor = idprofesor;
	}
	
	public String getIdprofesor() {
		return idprofesor;
	}

	public void setIdprofesor(String idprofesor) {
		this.idprofesor = idprofesor;
	}

	public String toString() {
		return super.toString() + " IDPROFESOR: "+ getIdprofesor();
	}
	
	
}
