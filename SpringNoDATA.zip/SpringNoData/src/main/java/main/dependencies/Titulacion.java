package main.dependencies;

import javax.persistence.*;

@Entity(name="titulacion")
@Table(name="titulacion")
public class Titulacion {
	
	@Id
	private String idtitulacion;
	
	private String nombre;

	public Titulacion(String idtitulacion, String nombre) {
		super();
		this.idtitulacion = idtitulacion;
		this.nombre = nombre;
	}

	public Titulacion() {
		super();
	}

	public String getIdtitulacion() {
		return idtitulacion;
	}

	public void setIdtitulacion(String idtitulacion) {
		this.idtitulacion = idtitulacion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return idtitulacion + ", " + nombre;
	}
	
	
	
}

