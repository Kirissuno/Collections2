package main.dependencies;

import javax.persistence.*;

@Entity(name="asignatura")
@Table(name="asignatura")
public class Asignatura {

	@Id
	private String idasignatura;
	private String nombre;
	private Integer creditos;
	private Integer cuatrimestre;
	private Integer costebasico;
	private String idprofesor;
	
	@ManyToOne
	@JoinColumn(name="idtitulacion", referencedColumnName="idtitulacion")
	private Titulacion titulacion;
	
	private Integer curso;
	
	public Asignatura() {
		super();
	}
	
	public Asignatura(String idasignatura) {
		this.idasignatura=idasignatura;
	}

	public Asignatura(String idasignatura, String nombre, int creditos, int cuatrimestre, int costebasico,
			String idprofesor, Titulacion idtitulacion, int curso) {
		super();
		this.idasignatura = idasignatura;
		this.nombre = nombre;
		this.creditos = creditos;
		this.cuatrimestre = cuatrimestre;
		this.costebasico = costebasico;
		this.idprofesor = idprofesor;
		this.titulacion = idtitulacion;
		this.curso = curso;
	}

	public String getIdasignatura() {
		return idasignatura;
	}

	public void setIdasignatura(String idasignatura) {
		this.idasignatura = idasignatura;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCreditos() {
		return creditos;
	}

	public void setCreditos(int creditos) {
		this.creditos = creditos;
	}

	public int getCuatrimestre() {
		return cuatrimestre;
	}

	public void setCuatrimestre(int cuatrimestre) {
		this.cuatrimestre = cuatrimestre;
	}

	public int getCostebasico() {
		return costebasico;
	}

	public void setCostebasico(int costebasico) {
		this.costebasico = costebasico;
	}

	public String getIdprofesor() {
		return idprofesor;
	}

	public void setIdprofesor(String idprofesor) {
		this.idprofesor = idprofesor;
	}

	public Titulacion getIdtitulacion() {
		return titulacion;
	}

	public void setIdtitulacion(Titulacion idtitulacion) {
		this.titulacion = idtitulacion;
	}

	public int getCurso() {
		return curso;
	}

	public void setCurso(int curso) {
		this.curso = curso;
	}

	@Override
	public String toString() {
		return idasignatura + ", " + nombre + ", " + creditos
				+ ", " + cuatrimestre + ", " + costebasico + ", " + idprofesor
				+ ", " + titulacion + ", " + curso;
	}

	
	
}
