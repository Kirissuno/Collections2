package main.dependencies;

import java.io.Serializable;

import javax.persistence.*;

@Entity(name="alumno")
@Table(name="alumno")
public class Alumno extends Persona implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String idalumno;	

	public Alumno() {
		super();
	}

	public Alumno(String idalumno, String dni) {
		super.setDni(dni);
		this.idalumno = idalumno;
	}

	public String getIdalumno() {
		return idalumno;
	}

	public void setIdalumno(String idalumno) {
		this.idalumno = idalumno;
	}

	
	public String toString() {
		return super.toString() + " idalumno: "+ getIdalumno();
	}
	
	
}
