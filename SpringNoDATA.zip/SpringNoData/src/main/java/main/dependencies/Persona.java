package main.dependencies;

import java.util.Date;

import javax.persistence.*;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Persona {
	
	@Id
	private String dni;
	
	private String Nombre;
	private String Apellido;
	private String Ciudad;
	private String Direccioncalle;
	private int Direccionnum;
	private String Telefono;
	private Date fecha_nacimiento;
	private int Varon;
	
	public Persona() {
		
	}

	public Persona(String dni) {
		super();
		this.dni = dni;
	}

	public Persona(String dni, String nombre, String apellido, String ciudad, String direccioncalle, int direccionnum,
			String telefono, int varon) {
		super();
		this.dni = dni;
		Nombre = nombre;
		Apellido = apellido;
		Ciudad = ciudad;
		Direccioncalle = direccioncalle;
		Direccionnum = direccionnum;
		Telefono = telefono;
		Varon = varon;
	}
	
	public Persona(String dni, String nombre, String apellido, String ciudad, String direccioncalle, int direccionnum,
			String telefono, Date fecha, int varon) {
		super();
		this.dni = dni;
		Nombre = nombre;
		Apellido = apellido;
		Ciudad = ciudad;
		Direccioncalle = direccioncalle;
		Direccionnum = direccionnum;
		Telefono = telefono;
		fecha_nacimiento = fecha;
		Varon = varon;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellido() {
		return Apellido;
	}

	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	public String getCiudad() {
		return Ciudad;
	}

	public void setCiudad(String ciudad) {
		Ciudad = ciudad;
	}

	public String getDireccioncalle() {
		return Direccioncalle;
	}

	public void setDireccioncalle(String direccioncalle) {
		Direccioncalle = direccioncalle;
	}

	public int getDireccionnum() {
		return Direccionnum;
	}

	public void setDireccionnum(int direccionnum) {
		Direccionnum = direccionnum;
	}

	public String getTelefono() {
		return Telefono;
	}

	public void setTelefono(String telefono) {
		Telefono = telefono;
	}

	public int getVaron() {
		return Varon;
	}

	public void setVaron(int varon) {
		Varon = varon;
	}

	public Date getFecha_nacimiento() {
		return fecha_nacimiento;
	}

	public void setFecha_nacimiento(Date fecha_nacimiento) {
		this.fecha_nacimiento = fecha_nacimiento;
	}

	@Override
	public String toString() {
		return dni + ", " + Nombre + ", " + Apellido + ", " + Ciudad
				+ ", " + Direccioncalle + ", " + Direccionnum + ", " + Telefono
				+ ", " + fecha_nacimiento + ", " + Varon;
	}

}
