package main;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import main.dependencies.Persona;
import main.dependencies.Titulacion;
import main.managers.Manager;


public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Manager<Titulacion> tmana = (Manager<Titulacion>) context.getBean("titulacionManagerImpl");
		
		System.out.println(tmana.listar());
		
	}

}
