package main.daoimpl;

import java.util.List;

import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import main.dao.DAO;
import main.dependencies.Persona;

@Repository
@Transactional
public class PersonaDAOimpl implements DAO<Persona> {

	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Persona persona) {
		em.persist(persona);		
	}

	@Override
	public List<Persona> listar() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Persona> cq = builder.createQuery(Persona.class);
		Root<Persona> root = cq.from(Persona.class);
		cq.select(root);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public void borrar(Persona persona) {
		em.remove(persona);
	}
	

	
	
}
