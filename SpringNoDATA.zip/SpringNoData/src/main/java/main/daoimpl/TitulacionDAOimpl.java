package main.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import main.dao.DAO;
import main.dependencies.Titulacion;

@Repository
@Transactional
public class TitulacionDAOimpl implements DAO<Titulacion> {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void insertar(Titulacion tit) {
		em.persist(tit);		
	}

	@Override
	public List<Titulacion> listar() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Titulacion> cq = builder.createQuery(Titulacion.class);
		Root<Titulacion> root = cq.from(Titulacion.class);
		cq.select(root);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public void borrar(Titulacion tit) {
		em.remove(tit);		
	}

}
