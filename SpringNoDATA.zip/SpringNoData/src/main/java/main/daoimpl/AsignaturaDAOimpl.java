package main.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import main.dao.DAO;
import main.dependencies.Asignatura;

@Repository
@Transactional
public class AsignaturaDAOimpl implements DAO<Asignatura> {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void insertar(Asignatura asi) {
		em.persist(asi);
	}

	@Override
	public List<Asignatura> listar() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Asignatura> cq = builder.createQuery(Asignatura.class);
		Root<Asignatura> root = cq.from(Asignatura.class);
		cq.select(root);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public void borrar(Asignatura asi) {
		em.remove(asi);
	}

}
