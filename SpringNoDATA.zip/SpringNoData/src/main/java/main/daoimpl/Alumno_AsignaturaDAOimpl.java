package main.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import main.dao.DAO;
import main.dependencies.Alumno_Asignatura;

@Repository
@Transactional
public class Alumno_AsignaturaDAOimpl implements DAO<Alumno_Asignatura> {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void insertar(Alumno_Asignatura aa) {
		em.persist(aa);
	}

	@Override
	public List<Alumno_Asignatura> listar() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Alumno_Asignatura> cq = builder.createQuery(Alumno_Asignatura.class);
		Root<Alumno_Asignatura> root = cq.from(Alumno_Asignatura.class);
		cq.select(root);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public void borrar(Alumno_Asignatura aa) {
		em.remove(aa);
	}

}
