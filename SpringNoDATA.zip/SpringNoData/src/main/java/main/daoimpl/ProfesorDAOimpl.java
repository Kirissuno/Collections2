package main.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import main.dao.DAO;
import main.dependencies.Profesor;

@Repository
@Transactional
public class ProfesorDAOimpl implements DAO<Profesor> {

	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Profesor pr) {
		em.persist(pr);
	}

	@Override
	public List<Profesor> listar() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Profesor> cq = builder.createQuery(Profesor.class);
		Root<Profesor> root = cq.from(Profesor.class);
		cq.select(root);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public void borrar(Profesor pr) {
		em.remove(pr);
	}
	
}
