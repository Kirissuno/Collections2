package main.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import main.dao.DAO;
import main.dependencies.Alumno;

@Repository
@Transactional
public class AlumnoDAOimpl implements DAO<Alumno> {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void insertar(Alumno al) {
		em.persist(al);
	}

	@Override
	public List<Alumno> listar() {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Alumno> cq = builder.createQuery(Alumno.class);
		Root<Alumno> root = cq.from(Alumno.class);
		cq.select(root);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public void borrar(Alumno al) {
		em.remove(al);
	}

}
